//Inbuilt & External packages
const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const session = require("express-session");
const cookieParser = require("cookie-parser");
const multer = require("multer");

//Database
const sequelize = require("./util/database");
const User = require("./models/user");
const Customer = require("./models/customer");
const Service = require("./models/service");

//Routes Imports
const authRoutes = require("./routes/auth_routes");
const customerRoutes = require("./routes/customer_routes");
const serviceRoutes = require("./routes/service_routes");
const userRoutes = require("./routes/user_routes");
const otherRoutes = require("./routes/other_routes");
const { json } = require("body-parser");
const varToExp = require("./controller/customer_controller");
const errorController = require("./controller/error_controller");

const oneDay = 1000 * 60 * 60 * 24;
const app = express();

const fileStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "images");
  },
  filename: (req, file, cb) => {
    cb(
      null,
      new Date().toJSON().slice(0, 19).replace("T", "-") +
        "-" +
        file.originalname
    ); //toDateString()
  },
});

const fileFilter = (req, file, cb) => {
  if (
    file.mimetype === "image/png" ||
    file.mimetype === "image/jpg" ||
    file.mimetype === "image/jpeg"
  ) {
    cb(null, true);
  } else {
    cb(null, false);
  }
};

//Middlewares
app.use(  multer({ storage: fileStorage, fileFilter: fileFilter }).single("image")); //'image' bcoz we have given input name='image'
app.use("/images", express.static(path.join(__dirname, "images"))); //Video 327, 2:15 duration for path confusion...
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(json());

app.use(
  session({
    secret: "thisismysecretkey",
    saveUninitialized: true,
    cookie: { maxAge: oneDay },
    resave: false,
  })
);
app.use(cookieParser());

app.set("view engine", "ejs");

app.locals.moment = require("moment");

//Main Routes
app.use("/auth", authRoutes);
app.use("/user", userRoutes);
app.use("/customer", customerRoutes);
app.use("/service", serviceRoutes);
app.use(otherRoutes);


// Error Routes
app.get("/500", errorController.get500);
app.use(errorController.get404);

app.use((error, req, res, next)=>{
  res.redirect('/500');
})

//Relationships
Customer.hasMany(Service);

sequelize
  .sync()
  .then((result) => {})
  .catch((err) => {
    console.log(err);
  });

app.listen(8999, () => console.log("Server started on port 8999"));

// 