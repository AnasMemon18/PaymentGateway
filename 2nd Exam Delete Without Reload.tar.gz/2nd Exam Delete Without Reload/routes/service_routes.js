const express = require("express");
const serviceController = require('../controller/service_controller');

const router = express.Router();

//Show
router.get('/showServices', serviceController.showServices);

//Add
router.get('/addServicePage', serviceController.addServicePage);
router.post('/addService',  serviceController.addService)

//Update
router.get('/updateService/:id', serviceController.getServiceById);
router.post('/updateService', serviceController.updateService);

//Delete
router.delete('/deleteService/:id', serviceController.deleteService);
router.get('/details/:id', serviceController.detailsPage);

//Checkout 
router.get('/checkout/success', serviceController.successCheckoutPage);
router.get('/checkout/failure', serviceController.detailsPage);

// router.post('/checkout', serviceController.checkoutMethod);
router.post('/checkout', serviceController.getCheckoutMethod);


module.exports = router;