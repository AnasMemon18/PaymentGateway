const express = require("express");

const userController = require('../controller/user_controller');

const router = express.Router();

router.post('/userregister', userController.insertUser);
router.post('/updateUser', userController.updateUser);
router.post('/successLogin', userController.isLoggedIn);


router.get('/showUsers', userController.getUsers);
router.get('/deleteUser/:id', userController.deleteUser);
router.get('/updateUser/:id', userController.getUserById);

module.exports = router;