const express = require("express");
const customerController = require("../controller/customer_controller");
const { check, body } = require("express-validator/check");
const router = express.Router();
const auth = require('../controller/auth_controller');

//Show
router.get("/showCustomers", auth.cookieJwtAuth, customerController.showCustomers);

//Add
router.get("/addCustomerPage", auth.cookieJwtAuth, customerController.addCustomerPage);

router.post(
  "/addCustomer", auth.cookieJwtAuth, 
  [
    check("name")
      .notEmpty()
      .withMessage("Please enter name.")
      .isAlpha()
      .withMessage("Name cannot contain digits."),
    check("email")
      .normalizeEmail()
      .isEmail()
      .withMessage("Please enter valid email."),
    body(
      "password",
      "Please enter a password with only numbers and text and at least 6 characters."
    )
      .isLength({ min: 6 })
      .isAlphanumeric(),
    check("phoneNumber")
      .notEmpty()
      .withMessage("Phone number can't be empty.")
      .isNumeric()
      .isLength({ min: 10, max: 10 })
      .withMessage("Phone number must be digits and only 10 characters."),
  ],
  customerController.insertCustomer
);

//Update
router.get("/updateCustomer/:id", auth.cookieJwtAuth, customerController.getCustomerById);
router.post("/updateCustomer", auth.cookieJwtAuth, customerController.updateCustomer);

//Delete
router.get("/deleteCustomer/:id", auth.cookieJwtAuth, customerController.deleteCustomer);

module.exports = router;
