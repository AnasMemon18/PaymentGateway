//Regex formats
var phoneFormat = /^[6-9]{1}[0-9]{9}$/;
var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
var nameFormat = /^[a-zA-Z]*$/g;


//Name on
function onNameChange(){
    var name = document.getElementById("name").value;
    if (name.length == "" ) {
      document.getElementById("name-err").innerHTML =
        "Please enter name!";
      return;
    }
    else if (!name.match(nameFormat)){
      document.getElementById("name-err").innerHTML =
        "Please enter valid name! It cannot have number or special character.";
    } else {
      document.getElementById("name-err").innerHTML = "";
    }
  }
  
  //Email onBlur
  function onEmailChange(){
    if (document.getElementById("email").value.match(mailformat)) {
      document.getElementById("email-err").innerHTML = "";
    } else {
      document.getElementById("email-err").innerHTML =
        "Please enter valid email!";
    }
  }
  
//PhoneNumber onBlur
function onPhNumberChange(){
    var phoneNumber = document.getElementById("phoneNumber").value;  
    if (!phoneNumber.match(phoneFormat)) {
      document.getElementById("phoneNumber-err").innerHTML =
        "Invalid phone number! Must be 10 digit and start from 6 to 9";
      return;
    } 
    else {
      document.getElementById("phoneNumber-err").innerHTML = "";
    }
  }


  //Password onBlur
function onPasswordChange(){
    var password = document.getElementById("password").value;
    if (
      password.length < 6 ||
      /[A-Z]/g.test(password) == false ||
      /\d/g.test(password) == false
    ) {
      document.getElementById("password-err").innerHTML =
        "Password length should be atleast 6. <br /> Password should contain atleast one digit. <br /> Password should contain atleast one capital letter.  ";
    }
    else{
      document.getElementById("password-err").innerHTML ="";
    }
  }


  //Whole form validation on click of submit button.
function validate() {
    document.getElementById("submit").addEventListener("click", function (event) {
  
      var name = document.getElementById("name").value;
      var password = document.getElementById("password").value;
      var phoneNumber = document.getElementById("phoneNumber").value;  
  
      // Name validation
      if (name.length == "" || !name.match(nameFormat)) {
        event.preventDefault();
        document.getElementById("name-err").innerHTML =
          "Please enter valid name!";
        return;
      } else {
        document.getElementById("name-err").innerHTML = "";
      }
  
      // Email validation
      if (!document.getElementById("email").value.match(mailformat)) {
        event.preventDefault();
        document.getElementById("email-err").innerHTML =
          "Please enter valid email!";
        return;
      } else {
        document.getElementById("email-err").innerHTML = "";
      }
  
      // Password validation
      if (
        password.length < 6 ||
        /[A-Z]/g.test(password) == false ||
        /\d/g.test(password) == false
      ) {
        document.getElementById("password-err").innerHTML =
          "Password length should be atleast 6. <br /> Password should contain atleast one digit. <br /> Password should contain atleast one capital letter.  ";
        event.preventDefault();
        return;
      } else {
        document.getElementById("password-err").innerHTML = "";
      }
  
  
      //Phone number validation
      if (!phoneNumber.match(phoneFormat)) {
        event.preventDefault();
        document.getElementById("phoneNumber-err").innerHTML =
          "Invalid phone number! Must be 10 digit and start from 6 to 9";
        return;
      } 
      else {
        document.getElementById("phoneNumber-err").innerHTML = "";
      }
    });
  }

  
