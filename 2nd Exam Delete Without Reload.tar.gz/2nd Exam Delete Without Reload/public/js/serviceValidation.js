//Regex formats
var phoneFormat = /^[0-9]+$/;



function vehicleBlur(){
    if(document.getElementById("vehicleNumber").value==""){
        document.getElementById("vehicleNumber-err").innerHTML = "Please enter vehicle number.";
    }
    else{
        document.getElementById("vehicleNumber-err").innerHTML = "";
    }
}


function locationBlur(){
    if(document.getElementById("location").value==""){
        document.getElementById("location-err").innerHTML = "Please enter location.";
    }
    else{
        document.getElementById("location-err").innerHTML = "";
    }
}

function serviceLocationBlur(){
    if(document.getElementById("serviceLocation").value==""){
        document.getElementById("serviceLocation-err").innerHTML = "Please enter service location.";
    }
    else{
        document.getElementById("serviceLocation-err").innerHTML = "";
    }
}

function servicePriceBlur(){
    if(document.getElementById("servicePrice").value==""){
        document.getElementById("servicePrice-err").innerHTML = "Please enter amount."
        return
    }
    else if(!document.getElementById("servicePrice").value.match(phoneFormat)){
        document.getElementById("servicePrice-err").innerHTML = "Please enter only digits."
        return
    }
    else{
        document.getElementById("servicePrice-err").innerHTML = ""
    }
}

function payableAmountBlur(){
    if(document.getElementById("payableAmount").value==""){
        document.getElementById("payableAmount-err").innerHTML = "Please enter amount."
        return
    }
    else if(!document.getElementById("payableAmount").value.match(phoneFormat)){
        document.getElementById("payableAmount-err").innerHTML = "Please enter only digits."
        return
    }
    else{
        document.getElementById("payableAmount-err").innerHTML = ""
    }
}

function validate(){
    document.getElementById("submit").addEventListener("click", function (event) {

        var vehicleNumber = document.getElementById("vehicleNumber").value;
        if(vehicleNumber==""){
            event.preventDefault();
            return
        }
    })
   
}