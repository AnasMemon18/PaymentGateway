function deleteService(btn){
    console.log("Clickeddd")
    // const serviceId = btn.parentNode.querySelector('[name=getId]').value;
    const serviceId = document.getElementById("getId").value;

    const cardElement = btn.closest('div')

    fetch('/service/deleteService/'+serviceId, {
        method:"DELETE"
    }).then(result=>{
        cardElement.remove();
        console.log("RESULT: ",result)  
    }).catch(err=>{
        console.log("ERROR: ", err);
    })
}