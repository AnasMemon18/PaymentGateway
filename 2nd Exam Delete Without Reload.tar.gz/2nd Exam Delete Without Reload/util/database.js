const Sequelize = require("sequelize");

const sequelize = new Sequelize(
    'nodedemo',
    'anas',
    'password', 
    {
        Server: 'localhost',
        dialect : 'postgres'
    }
);


sequelize.authenticate().then(()=>{console.log("")}).catch(err=>{
        console.log(err)
    })
    
module.exports = sequelize;
   
   
   
// const sequelize = new Sequelize("demo", "root", "Password@123", {
//     dialect:"mysql",
//     host: 'localhost'
// })