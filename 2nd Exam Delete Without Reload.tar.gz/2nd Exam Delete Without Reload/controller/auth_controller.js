const session = require("express-session");
const nodeMailer = require("nodemailer");
const path = require("path");
const User = require("../models/user");
const jwt = require("jsonwebtoken");

var date = new Date().toISOString().split("T")[0];
var sentOtp;
var mainUserId;

const authLogin = async (req, res, next) => {
  const {email, password} = req.body;
  const user = await User.findOne({ where: { email: email } });
  try {
    if (user) {
      if (user.password === password) {
        jwt.sign(
          {
            userId: user.id,
          },
          "secretkey",
          (err, token) => {
            if (err) {
              throw err;
            } else {
              res.cookie("jwt", token, { httpOnly: true, maxAge: 600 * 1000 }); //10 minutes
              res.redirect("/dashboard");
            }
          }
        );
      } else {
        res.render(path.join(__dirname, "../", "views", "auth", "auth-login"), {
          message: "Password incorrect. Please enter correct password.", email, password
        });
      }
    } else {
      res.render(path.join(__dirname, "../", "views", "auth", "auth-login"), {
        message: "You are not a registered user, Please sign up.", email, password
      });
    }
  } catch (err) {
    console.log("ksadfjh")
    throw err;
  }
};

const authLoginPage = (req, res, next) => {
  res.render(path.join(__dirname, "../", "views", "auth", "auth-login"));
};

const authRegisterPage = (req, res, next) => {
  res.render(path.join(__dirname, "../", "views", "auth", "auth-register"), {
    date: date,
  });
};

const cookieJwtAuth = (req, res, next) => {
  const token = req.cookies.jwt;
  console.log("TOKEN: ", token);
  try {
    const user = jwt.verify(token, "secretkey");
    req.user = user;
    console.log("Users: ", req.user);
    next();
  } catch (err) {
    console.log("In error block")
    res.clearCookie("jwt");
    res.redirect("/");
  }
};

const authRegister = async (req, res, next) => {
  try {
    const user = await User.findOne({ where: { email: req.body.email } });
    if (user) {
      console.log(user);
      res.render(
        path.join(__dirname, "../", "views", "auth", "auth-register"),
        { emailMessage: "Email already registered, Please try logging in." }
      );
      // res.redirect('/');
    } else {
      User.create({
        name: req.body.name,
        email: req.body.email,
        password: req.body.confirmPassword,
        phoneNumber: req.body.phoneNumber,
        dob: req.body.dateOfBirth,
      })
        .then((user) => {
          res.redirect("/auth/login-page");
        })
        .catch((err) => {
          console.log("Insertion Error!");
          throw err;
        });
    }
  } catch (err) {
    throw err;
  }
};

const authForgotPassPage = (req, res, next) => {
  res.render(path.join(__dirname, "../", "views", "auth", "auth-forgot"));
};

const authForgot = async (req, res, next) => {
  const user = await User.findOne({ where: { email: req.body.email } });
  try {
    if (user) {
      mainUserId = user.id;
      sentOtp = Math.floor(1000 + Math.random() * 9000);

      var transporter = nodeMailer.createTransport({
        service: "gmail",
        auth: {
          user: "anasmemon7864@gmail.com",
          pass: "aczq aqoc xbni smnr",
        },
      });

      var mailOptions = {
        from: "anasmemon7864@gmail.com",
        to: user.email,
        subject: "Otp sent from mentor for forgot password.",
        text: `Your Otp for forgot password: ${sentOtp}`,
      };

      transporter.sendMail(mailOptions, function (error, info) {
        if (error) {
          console.log(error);
        } else {
          console.log("Email sent: " + info.response);
        }
      });
      console.log(sentOtp);

      res.render(path.join(__dirname, "../", "views", "auth", "auth-otp"));
    } else {
      res.render(path.join(__dirname, "../", "views", "auth", "auth-forgot"), {
        message: "Email doesn't exist.",
      });
    }
  } catch (err) {
    throw err;
  }
};

const authOtp = (req, res, next) => {
  var enteredOtp = parseInt(req.body.otp);
  // console.log(enteredOtp, " ", typeof(enteredOtp))

  if (enteredOtp == sentOtp) {
    res.render(
      path.join(__dirname, "../", "views", "auth", "auth-pass-change")
    );
  } else {
    res.render(path.join(__dirname, "../", "views", "auth", "auth-otp"), {
      message: "Invalid Otp!",
    });
  }
};

const authChangePassword = (req, res, next) => {
  try {
    User.update(
      {
        password: req.body.confirmPassword,
      },
      {
        where: { id: mainUserId },
      }
    )
      .then((user) => {
        res.redirect("/auth/login-page");
      })
      .catch((err) => {
        throw err;
      });
  } catch (err) {
    throw err;
  }
};

const logout = (req, res, next) => {};

module.exports = {
  authLoginPage,
  authLogin,
  authRegisterPage,
  authRegister,
  authForgotPassPage,
  authForgot,
  authOtp,
  authChangePassword,
  logout,
  cookieJwtAuth,
};
