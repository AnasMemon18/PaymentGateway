const Service = require('../models/service');
const Customer = require('../models/customer');
const path = require("path");
const stripe = require("stripe")('sk_test_51MeB91SHsycH3BqvClK3wSrXgqmZvxNEgcaTrf4dIx4yPjpUn1EyhvF4aFjlTWOpcHhjNfID0OU6zbC8Xg97mcZE00vHGMwMyl')

var date = new Date().toISOString().split("T")[0];


//Display Services
const showServices = (req, res, next)=>{
    try {
        Service.findAll()
        .then(result => {
            res.render(path.join(__dirname, "../", "views", "service", "showServices"), {services: result});
        })
        .catch(err => {
            throw err;
        })
} catch (err) {
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
}
};

//Add Service Page
const addServicePage = (req, res, next)=>{
    try{
        Customer.findAll()
            .then(result=>{
                res.render(path.join(__dirname, "../", "views", "service", "addServicePage"), {customers: result, date:date});
            }).catch(err=>{
                console.log(err);
            })
    }catch(err){
        const error = new Error(err);
        error.httpStatusCode = 500;
        return next(error);
    }
}

//Add service in services database.
const addService = (req, res, next)=>{
    var customer = req.body.customerName;
    var customerId = customer.split(".")[0];
    var customerName = customer.split(". ")[1];
  try {
   {
        Service.create({
            customerName: customerName,
            vehicleNumber: req.body.vehicleNumber,
            pickupDate: req.body.pickupDate,
            dropDate: req.body.dropDate,
            location: req.body.location,
            serviceLocation: req.body.serviceLocation,
            servicePrice: req.body.servicePrice,
            payableAmount: req.body.payableAmount,
            customerId: customerId
        })
            .then((customer) => {
                res.redirect('/service/showServices');
               
            })
            .catch(err => {
                console.log("Insertion Error!");
                throw err;
            })
    }
}
catch (err) {
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
}
}

var details;
//Displaying details of selected customer.
const detailsPage = async (req, res, next)=>{
    const id = req.params.id;
    let getService;
  try{
    await Customer.findOne({where: {id: id}}).then(service=>{
            getService = service;   
            Service.findAll({where:{customerId: service.id}}).then((result)=>{
                details =result
                res.render(path.join(__dirname, "../", "views", "service", "details"), {details: result, getService:getService, sessionId: ""});
        }).catch(err=>{
            console.log(err)
        })
    })
    
}catch(err){
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
}
};


//Fetching services by id
const getServiceById = (req, res, next)=>{
    var custData;
    Customer.findAll()
            .then(result=>{
                custData = result
            })
            const id = req.params.id;
    try {
        Service.findByPk(id)
            .then(data => {
                res.render(path.join(__dirname, "../", "views", "service", "updateService"), { date: date, data: data, customers: custData });
            })
            .catch(err => {
                throw err;
            })
    } catch (err) {
        const error = new Error(err);
        error.httpStatusCode = 500;
        return next(error);
    }
};


//Update service
const updateService = (req, res, next)=>{
    var customer = req.body.customerName;
    var customerId = customer.split(".")[0];
    var customerName = customer.split(". ")[1];
  
    try {
        Service.update({
            customerName: customerName,
            vehicleNumber: req.body.vehicleNumber,
            pickupDate: req.body.pickupDate,
            dropDate: req.body.dropDate,
            location: req.body.location,
            serviceLocation: req.body.serviceLocation,
            servicePrice: req.body.servicePrice,
            payableAmount: req.body.payableAmount,
            customerId: customerId
        }, {
            where: { id: req.body.id }
        }).then(service => {
            res.redirect('/service/showServices');
        }).catch(err => {
            throw err;
        })
    } catch (err) {
        const error = new Error(err);
        error.httpStatusCode = 500;
        return next(error);
    }
};

//Delete service
const deleteService = (req, res, next)=>{
    const id = req.params.id;
    try {
        Service.findByPk(id).then(result=>{
            result.destroy();
           res.status(200).json({message: "Success!"})
        }).catch(err=>{
           res.status(500).json({message: "Deleting service failed!"})
            
        })
    } catch (err) {
        const error = new Error(err);
        error.httpStatusCode = 500;
        return next(error);
    }
};


const successCheckoutPage = (req, res, next)=>{
    res.render(path.join(__dirname, "../", "views", "service", "successCheckoutPage"));
}

var status;
const getCheckoutMethod = (req, res, next)=>{
    const {sum, totalServices, name} = req.body;
    return stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [ 
            { 
              price_data: { 
                currency: "inr", 
                product_data: { 
                  name: "Vehicle Services",
                  description: `Total vehicles: ${totalServices}`
                }, 
                unit_amount: sum*100, 
              }, 
              quantity: 1, 
            }, 
          ], 
        mode: 'payment',
        success_url: req.protocol+ '://' +req.get('host') + '/service/checkout/success', //http://localhost/service/checkout/success
        cancel_url: req.protocol+ '://' +req.get('host') + '/service/checkout/cancel',
    }).then(session=>{
        status= true;
        if(status){

        }
        res.render(path.join(__dirname, "../", "views", "service", "checkout"), {sessionId: session.id, name, sum})
    }).catch(err=>{
        console.log("Checkout error: ", err);
       })
};

//Exports
module.exports = {
    showServices,
    addServicePage,
    addService,
    detailsPage,
    getServiceById,
    updateService,
    deleteService,
    successCheckoutPage,
    getCheckoutMethod
}