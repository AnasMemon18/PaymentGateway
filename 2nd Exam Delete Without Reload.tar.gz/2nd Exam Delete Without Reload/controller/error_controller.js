const path = require("path");

const get404 = (req, res, next)=>{
    res.render(path.join(__dirname, "../", "views", "error", "404"));
}

const get500 = (req, res, next)=>{
    res.render(path.join(__dirname, "../", "views", "error", "500"));
}

module.exports = {
    get404, 
    get500
};