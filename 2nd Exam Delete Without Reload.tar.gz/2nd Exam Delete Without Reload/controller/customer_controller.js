const Customer = require("../models/customer");
const path = require("path");
const bcrypt = require("bcrypt");
const fs = require("fs");
const { validationResult } = require("express-validator/check");
var date = new Date().toISOString().split("T")[0];


//Display Customer
const showCustomers = (req, res, next) => {
  try {
    Customer.findAll({ where: { isDeleted: 0 } })
      .then((result) => {
        res.render(
          path.join(__dirname, "../", "views", "customer", "showCustomers"),
          { customers: result }
        );
      })
      .catch((err) => {
        throw err;
      });
  } catch (err) {
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
  }
};

//Insert Customer in customers database
const insertCustomer = async (req, res, next) => {
  console.log(req.body)
  const {name, email, phoneNumber, dob, password, country, address} = req.body;
  const image = req.file;

  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res
      .status(422)
      .render(
        path.join(__dirname, "../", "views", "customer", "addCustomerPage"),
        {
          date: date,
          oldInput:{name, email, password, country, dob, phoneNumber, address},
          errorMessage: errors.array()[0].msg,
        }
      );
  }


  try {
    const customer = await Customer.findOne({
      where: { email: req.body.email },
    });
    if (customer) {
      try {
        Customer.update(
          {
            isDeleted: 0,
          },
          {
            where: { email: customer.email },
          }
        )
          .then((customer) => {
            res.redirect("/customer/showCustomers");
          })
          .catch((err) => {
            throw err;
          });
      } catch (err) {
        console.log(err);
      }
    } else {
      if (!image) {
        return;
      } else {
        
        Customer.create({
          name,
          email,
          phoneNumber,
          dob,
          password: await bcrypt.hash(password, 10),
          country,
          address,
          imageUrl: image.path.split("/")[1],
        })
          .then((customer) => {
            res.redirect("/customer/showCustomers");
          })
          .catch((err) => {
            console.log("Insertion Error!");
            throw err;
          });
      }
    }
  } catch (err) {
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
  }
};


//Add Customer Page
const addCustomerPage = (req, res, next) => {
  res.render(
    path.join(__dirname, "../", "views", "customer", "addCustomerPage"),
    {
      date: date,
      oldInput: {
        name: "",
        email: "",
        password: "",
        country:"",
        phoneNumber: "",
        address: "",
      },
    }
  );
};


//Fetching customer by id
const getCustomerById = (req, res, next) => {
  const id = req.params.id;
  try {
    Customer.findByPk(id)
      .then((data) => {
        console.log(data);
        res.render(
          path.join(__dirname, "../", "views", "customer", "updateCustomer"),
          { date: date, data: data }
        );
      })
      .catch((err) => {
        throw err;
      });
  } catch (err) {
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
  }
};


//Update customer
const updateCustomer = async (req, res, next) => {
  const {name, email, phoneNumber, dob, country, address} = req.body;
  var image = req.file;
  var customerUrl;
  await Customer.findOne({ where: { id: req.body.id } }).then((result) => {
    customerUrl = result.imageUrl;
  });

  if (image === undefined) {
    Customer.update(
      {
        name,
        email,
        phoneNumber,
        dob,
        country,
        address,
        imageUrl: customerUrl,
      },
      {
        where: { id: req.body.id },
      }
    )
      .then((customer) => {
        res.redirect("/customer/showCustomers");
      })
      .catch((err) => {
        throw err;
      });
  } else {
    const path = "images/" + customerUrl;
    try {
      fs.unlinkSync(path);
    } catch (err) {}
    Customer.update(
      {
        name,
        email,
        phoneNumber,
        dob,
        country,
        address,
        imageUrl: image.path.split("/")[1],
      },
      {
        where: { id: req.body.id },
      }
    )
      .then((customer) => {
        res.redirect("/customer/showCustomers");
      })
      .catch((err) => {
        throw err;
      });
  }
};


//Delete customer
const deleteCustomer = async (req, res, next) => {
  const id = req.params.id;
  try {
    Customer.findOne({ where: { id: id } })
      .then((res) => {
        var customerUrl = res.imageUrl;
        const path = "images/" + customerUrl;
        try {
          fs.unlinkSync(path);
          console.log("File removed:", path);
        } catch (err) {
          console.error(err);
        }
      })
      .catch((err) => {
        console.log(err);
      });

    //Soft delete with the helo of updation...
    Customer.update(
      {
        isDeleted: 1,
      },
      {
        where: { id: id },
      }
    )
      .then((customer) => {
        res.redirect("/customer/showCustomers");
      })
      .catch((err) => {
        throw err;
      });
  } catch (err) {
    const error = new Error(err);
    error.httpStatusCode = 500;
    return next(error);
  }
};


//Exports
module.exports = {
  showCustomers,
  insertCustomer,
  addCustomerPage,
  getCustomerById,
  updateCustomer,
  deleteCustomer,
};
