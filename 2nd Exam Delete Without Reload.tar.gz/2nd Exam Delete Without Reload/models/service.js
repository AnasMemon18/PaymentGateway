const Sequelize = require("sequelize");

const sequelize = require("../util/database");

const Service = sequelize.define("service", {
  id: {
    type: Sequelize.INTEGER,
    allowNull: false,
    primaryKey: true,
    autoIncrement: true,
  },
  customerName: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  vehicleNumber: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  pickupDate: {
    type: Sequelize.DATEONLY,
    allowNull: false,
  },
  dropDate: {
    type: Sequelize.DATEONLY,
    allowNull: false,
  },
  location: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  serviceLocation: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  servicePrice: {
    type: Sequelize.INTEGER,
    allowNull: false,
  },
  payableAmount:{
    type: Sequelize.INTEGER,
    allowNull: false,
  }
}, {paranoid: true, deletedAt: 'softDelete'});

module.exports = Service;
